package com.remiseria.model;

import jakarta.persistence.*;
import java.time.*;

@Entity
@Table(name = "chofer")
public class Chofer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombreApellido;
    private String auto;
    private String dni;   
    private LocalDate fechaFinLic;

    public Chofer() {}


    public Long getIdChofer() {
        return id;
    }

    public String getNombreApellido() {
        return nombreApellido;
    }

    public void setNombreApellido(String nombreApellido) {
        this.nombreApellido = nombreApellido;
    }

    public String getAuto() {
        return auto;
    }

    public void setAuto(String auto) {
        this.auto = auto;
    }


    public String getDni() {
        return dni;
    }


    public void setDni(String dni) {
        this.dni = dni;
    }


    public LocalDate getFechaFinLic() {
        return fechaFinLic;
    }


    public void setFechaFinLic(LocalDate fechaFinLic) {
        this.fechaFinLic = fechaFinLic;
    }
}
