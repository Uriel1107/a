package com.remiseria.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.remiseria.model.Chofer;
import com.remiseria.Repository.ChoferRepository;

@Controller
public class ChoferController {

    @Autowired
    private ChoferRepository choferRepository;

    // Muestra la lista de choferes
    @GetMapping("/choferes")
    public String mostrarListaChoferes(Model model) {
        List<Chofer> choferes = choferRepository.findAll();
        model.addAttribute("choferes", choferes); // Usar "choferes" para el nombre
        return "choferes"; 
    }

    // Muestra el formulario de creación
    @GetMapping("/chofer/crear")
    public String mostrarFormularioCrear() {
        return "crearchofer";  // Nombre del archivo HTML para crear chofer
    }

    // Procesa el formulario de creación
    @PostMapping("/chofer")
    public String createChofer(@RequestParam("nombreyape") String nombreyape, 
                               @RequestParam("auto") String auto) {
        Chofer chofer = new Chofer();
        chofer.setNombreApellido(nombreyape);
        chofer.setAuto(auto);
        choferRepository.save(chofer);
        return "redirect:/chofer";
    }

    // Obtiene un chofer por ID
    @GetMapping("/chofer/{id}")
    public ResponseEntity<Chofer> getChoferById(@PathVariable Long id) {
        Optional<Chofer> chofer = choferRepository.findById(id);
        return chofer.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Actualiza un chofer por ID
    @PutMapping("/chofer/{id}")
    public ResponseEntity<Chofer> updateChofer(@PathVariable Long id, @RequestBody Chofer choferDetails) {
        return choferRepository.findById(id)
                .map(chofer -> {
                    chofer.setNombreApellido(choferDetails.getNombreApellido());
                    chofer.setAuto(choferDetails.getAuto());
                    Chofer updatedChofer = choferRepository.save(chofer);
                    return ResponseEntity.ok(updatedChofer);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // Elimina un chofer por ID
    @DeleteMapping("/chofer/{id}")
    public ResponseEntity<Void> deleteChofer(@PathVariable Long id) {
        Optional<Chofer> optionalChofer = choferRepository.findById(id);
        if (optionalChofer.isPresent()) {
            choferRepository.delete(optionalChofer.get());
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
