package com.remiseria.model;

import jakarta.persistence.*;

@Entity
@Table(name = "chofer")
public class Chofer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long IdChofer;
    private String NyA;
    private String Auto;

    public Long getIdChofer() {
        return IdChofer;
    }

    public String getNombreApellido() {
        return NyA;
    }

    public void setNombreApellido(String NyA) {
        this.NyA = NyA;
    }

    public String getAuto() {
        return Auto;
    }

    public void setAuto(String Auto) {
        this.Auto = Auto;
    }
}

