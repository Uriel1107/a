package main.java.com.example.remiseria.controllers;
@Controller
public class IndexController {

    @GetMapping("/")
    public String index() {
        return "index"; // Aquí debes tener un archivo index.html en tu carpeta de templates
    }

    @GetMapping("/choferes/new")
    public String mostrarFormularioCrearChofer(Model model) {
        model.addAttribute("chofer", new Chofer());
        return "crearChofer"; // El nombre del HTML para crear chofer
    }

    @GetMapping("/choferes/edit")
    public String mostrarFormularioEditarChofer() {
        // Aquí podrías pedir al usuario que seleccione qué chofer editar
        return "editarChofer";
    }

    @GetMapping("/choferes/delete")
    public String mostrarFormularioEliminarChofer() {
        // Aquí podrías pedir al usuario que seleccione qué chofer eliminar
        return "eliminarChofer";
    }

    @GetMapping("/choferes")
    public String listarChoferes(Model model) {
        model.addAttribute("choferes", choferRepository.findAll());
        return "listarChoferes"; // El HTML que muestra la lista de choferes
    }
}

