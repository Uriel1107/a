package com.example.remiseria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RemiseriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RemiseriaApplication.class, args);
	}

}
