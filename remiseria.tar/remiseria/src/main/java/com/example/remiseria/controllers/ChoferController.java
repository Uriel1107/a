package com.example.remiseria.controllers;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import main.java.repository.ChoferRepository;



@Controller
public class ChoferController {

    @Autowired
    private ChoferRepository choferRepository;

    @GetMapping("/choferes")
    public List<Closer> getAllChoferes() {
        return choferRepository.findAll();
    }

    @PostMapping
    public Chofer createChofer(@RequestBody Chofer chofer) {
        return choferRepository.save(chofer);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Chofer> getChoferById(@PathVariable Long id) {
        Optional<Chofer> chofer = choferRepository.findById(id);
        if (chofer.isPresent()) {
            return ResponseEntity.ok(chofer.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Chofer> updateChofer(@PathVariable Long id, @RequestBody Chofer choferDetails) {
        return choferRepository.findById(id)
                .map(chofer -> {
                    chofer.setNombreApellido(choferDetails.getNombreApellido());
                    chofer.setAuto(choferDetails.getAuto());
                    Chofer updatedChofer = choferRepository.save(chofer);
                    return ResponseEntity.ok(updatedChofer);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteChofer(@PathVariable Long id) {
        Optional<Chofer> optionalChofer = choferRepository.findById(id);
        if (optionalChofer.isPresent()) {
            choferRepository.delete(optionalChofer.get());
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

}
