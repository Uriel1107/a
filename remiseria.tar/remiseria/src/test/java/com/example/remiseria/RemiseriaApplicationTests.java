package com.example.remiseria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RemiseriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
