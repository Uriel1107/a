package com.agencia.model;
import jakarta.persistence.*;


@Entity
@Table(name = "viaje")
public class Viaje {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long IdViaje;
    @ManyToOne
    @JoinColumn(name = "IdChofer")
    private Chofer Chofer;
    private String Localidad;

    public Long getIdViaje() {
        return IdViaje;
    }

    public Chofer getChofer() {
        return Chofer;
    }

    public void setChofer(Chofer Chofer) {
        this.Chofer = Chofer;
    }

    public String getLocalidad() {
        return Localidad;
    }

    public void setLocalidad(String Localidad) {
        this.Localidad = Localidad;
    }

    public Object getIdChofer() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getIdChofer'");
    }
}