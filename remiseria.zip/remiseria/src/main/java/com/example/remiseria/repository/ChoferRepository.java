package com.example.remiseria.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.agencia.model.Chofer;

@Repository
public interface ChoferRepository extends JpaRepository<Chofer, Long> {
}
