package com.example.remiseria.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import com.agencia.model.Viaje;
import com.example.remiseria.repository.ViajeRepository;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("/viajes")
public class ViajeController {

    @Autowired
    private ViajeRepository viajeRepository;

    @GetMapping
    public List<Viaje> getAllViajes() {
        return viajeRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Viaje> getViajeById(@PathVariable Long id) {
        Optional<Viaje> viaje = viajeRepository.findById(id);
        if (viaje.isPresent()) {
            return ResponseEntity.ok(viaje.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    @PostMapping
    public Viaje createViaje(@RequestBody Viaje viaje) {
        return viajeRepository.save(viaje);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Viaje> updateViaje(@PathVariable Long id, @RequestBody Viaje viajeDetails) {
        Optional<Viaje> optionalViaje = viajeRepository.findById(id);
        if (optionalViaje.isPresent()) {
            Viaje viaje = optionalViaje.get();
            viaje.getIdChofer();
            //viaje.setIdChofer(viajeDetails.getIdChofer()); el set no va pq es un dato que se carga solo en la bdd
            viaje.setLocalidad(viajeDetails.getLocalidad());
            Viaje updatedViaje = viajeRepository.save(viaje);
            return ResponseEntity.ok(updatedViaje);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteViaje(@PathVariable Long id) {
        Optional<Viaje> optionalViaje = viajeRepository.findById(id);
        if (optionalViaje.isPresent()) {
            viajeRepository.delete(optionalViaje.get());
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}